HEAD
# wp-build - Monday Week 2#
- Checkout new branch for Monday Week 2, add, commit, and push
```sh
git checkout -b monday-wk2
git add .
git commit -m "start of Monday - Week 2"
git push origin monday-wk2
```
- Using Google and W3Schools figure out how to make the following changes to your page:
1. Completely remove the html5 logo at the top of the page
2. Add a background image to the body using this link ```http://lorempixel.com/g/800/800``` that completely covers the entire page
3. Give your ```container``` a background color of white, rounded corners, and padding

